# Zaffle — starter project

Backing code for the Zaffle TRD: a PWA where a licensed nonprofit runs
home raffles, brokers submit listings, and buyers purchase numbered
tickets from a fixed pool.

## What's here

- `supabase/migrations/0001_init.sql` — full Postgres schema, RLS
  policies, and the atomic `purchase_tickets()` function that prevents
  overselling the fixed ticket pool under concurrent buyers.
- `supabase/functions/raffle-engine` — scheduled Edge Function that
  closes raffles at their deadline, checks the minimum-raise threshold,
  and runs the draw or flags the raffle for a lister/admin decision.
- `supabase/functions/stripe-webhook` — handles `payment_intent.succeeded`
  and `charge.refunded` events from Stripe Connect.
- `src/lib/supabaseClient.js` — frontend Supabase client and example
  queries.

## What you need to fill in before this is live

1. **Create a Supabase project** and run the migration:
   ```
   supabase link --project-ref <your-project-ref>
   supabase db push
   ```
2. **Enable PostGIS** — the migration does this automatically, but
   confirm it under Database > Extensions if you hit an error.
3. **Create a Stripe Connect platform account** and set the secret keys
   as Edge Function secrets:
   ```
   supabase secrets set STRIPE_SECRET_KEY=sk_... STRIPE_WEBHOOK_SECRET=whsec_...
   ```
4. **Schedule the raffle engine** — Supabase Edge Functions don't run on
   a timer by themselves. Use `pg_cron` (Database > Cron Jobs) to call
   the function's URL every few minutes, or an external scheduler.
5. **Finalize the draw method** (see TRD Section 11, item 2) — the
   current `drawWinner()` function in `raffle-engine/index.ts` uses
   `crypto.getRandomValues`, which is cryptographically sound but not
   yet auditable after the fact. Whoever owns compliance should sign
   off on the final provably-fair approach before this goes live with
   real raffles.
6. **Add real license/permit verification** — the schema has the
   fields (`license_verified`, `raffle_permits`), but the actual
   verification step (manual review vs. a state licensing-board API)
   still needs to be built.
7. **Legal review** — the pilot state's charitable raffle statute needs
   to be checked against `state_rulesets` before launch. This starter
   code enforces whatever values you put in that table, but doesn't
   know the rules itself.

## Local development

```
npm install
cp .env.example .env   # fill in your Supabase + Stripe keys
npm run dev
```

The design prototype (`Zaffle_prototype` artifact) is a good reference
for the buyer-facing UI this starter code is meant to power — it's
built with mock data, so wiring it to `supabaseClient.js` is the next
step once your project is live.
